extern void  PSplot_phylogeny(Union *cluster, char *filename, char *type);
