#ifndef _WMATCH_H_
#define _WMATCH_H_

#ifdef __cplusplus
extern "C" {
#endif

    int *Weighted_Match (void *gptr,int type,int maximize);

#ifdef __cplusplus
}
#endif

#endif
